from flask import Flask, render_template, request, redirect
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
@app.route("/")
def home():
    return render_template("home.html")


# -------------------------------
# MySQL Connection
# -------------------------------
app.config["SQLALCHEMY_DATABASE_URI"] = "mysql+pymysql://root:Siri123.@localhost:3306/details"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)

# ---------------------------------------------------
# TABLE 1: Pd
# ---------------------------------------------------
class Pd(db.Model):
    __tablename__ = "Pd"

    Aadhar_no = db.Column(db.BigInteger, primary_key=True, nullable=False)
    Full_name = db.Column(db.String(1000), nullable=False)
    age = db.Column(db.Integer, nullable=False)
    Phone_no = db.Column(db.BigInteger, nullable=False)

    vulnerabilities = db.Column(db.Text)
    Experience = db.Column(db.Text)



# ---------------------------------------------------
# TABLE 2: Jl
# ---------------------------------------------------
class Jl(db.Model):
    __tablename__ = "Jl"

    Employer = db.Column(db.String(50), primary_key=True, nullable=False)
    Employer_Phoneno = db.Column(db.BigInteger)

    jb_name = db.Column(db.String(50), nullable=False)
    Availability = db.Column(db.Integer)

    location = db.Column(db.String(50))
    Fixed_wage_per_hr = db.Column(db.Numeric(5, 2))
    Job_description = db.Column(db.Text)


# ---------------------------------------------------
# TABLE 3: J_A
# ---------------------------------------------------
class J_A(db.Model):
    __tablename__ = "J_A"

    Aadhar_no = db.Column(
        db.BigInteger,
        db.ForeignKey("Pd.Aadhar_no"),
        primary_key=True
    )

    Assigned_jb = db.Column(db.String(50))
    Assigned = db.Column(db.Boolean, default=False)

@app.route("/register", methods=["GET", "POST"])
def register():
    error = None

    if request.method == "POST":
        clean_aadhar = request.form["aadhar"].replace(" ", "")

        if len(clean_aadhar) != 12:
            error = "Please enter a valid 12-digit Aadhar number."

        else:
            worker = Pd(
                Aadhar_no=clean_aadhar,
                Full_name=request.form["name"],
                age=request.form["age"],
                Phone_no=request.form["phone"],
                vulnerabilities=request.form["vulnerabilities"],
                Experience=request.form["experience"],
            )

            db.session.add(worker)
            db.session.commit()
            return redirect("/workers")

    return render_template("register.html", error=error)

@app.route("/workers")
def workers():
    all_workers = Pd.query.all()
    return render_template("workers.html", workers=all_workers)

@app.route("/add_job", methods=["GET", "POST"])
def add_job():
    if request.method == "POST":
        job = Jl(
            Employer=request.form["employer"],
            Employer_Phoneno=request.form["phone"],
            jb_name=request.form["jobname"],
            Availability=request.form["availability"],
            location=request.form["location"],
            Fixed_wage_per_hr=request.form["wage"],
            Job_description=request.form["description"]
        )

        db.session.add(job)
        db.session.commit()
        return redirect("/jobs")

    return render_template("add_job.html")

@app.route("/jobs")
def jobs():
    all_jobs = Jl.query.all()
    return render_template("jobs.html", jobs=all_jobs)

@app.route("/assign_job", methods=["GET", "POST"])
def assign_job():
    if request.method == "POST":
        assignment = J_A(
            Aadhar_no=request.form["aadhar"],
            Assigned_jb=request.form["job"],
            Assigned=True
        )

        db.session.add(assignment)
        db.session.commit()
        return "Job Assigned Successfully!"

    return render_template("assign_job.html")

if __name__ == "__main__":
    app.run(debug=True)
