create database details;
use details;
create table Pd(Aadhar_no BIGINT NOT NULL PRIMARY KEY,Full_name varchar(1000) NOT NULL, 
age int NOT NULL,Phone_no BIGINT NOT NULL, vulnerabilities TEXT, Experience TEXT, Urgency_score decimal(5,2) NOT NULL);

create table Jl(Employer varchar(50) NOT NULL PRIMARY KEY,Employer_Phoneno BIGINT,
jb_name varchar(50) NOT NULL, Availability int, 
location varchar(50),Fixed_wage_per_hr decimal(5,2));

create table J_A(Aadhar_no BIGINT,FOREIGN KEY(Aadhar_no) REFERENCES Pd(Aadhar_no),
 Assigned_jb varchar(50), Assigned bool DEFAULT FALSE);
 
 Select * FROM Jl;

ALTER TABLE Pd DROP COLUMN Urgency_score;
ALTER TABLE Jl ADD Job_description TEXT;
TRUNCATE TABLE Jl;
TRUNCATE TABLE Pd;
TRUNCATE TABLE J_A;
 Delete from Pd Where Full_name="dw";